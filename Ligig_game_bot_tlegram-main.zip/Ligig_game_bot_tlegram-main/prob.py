from main import yes
print()