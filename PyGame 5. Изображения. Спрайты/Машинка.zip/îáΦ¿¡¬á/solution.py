import sys

import pygame
from pygame.locals import *


class Car(object):
    def __init__(self):
        self.image = pygame.image.load('car2.png')
        self.x = 95 // 2
        self.y = 0
        self.cor = 10

    def draw(self, surface):
        self.x += self.cor
        if self.x <= 0 or self.x >= 600:
            self.cor *= -1
            self.image = pygame.transform.flip(self.image, True, False)

        surface.blit(self.image, (self.x, self.y))
        pygame.display.update()


pygame.init()
screen = pygame.display.set_mode((600, 95))
cat = Car()
Clock = pygame.time.Clock()

running = True
while running:
    screen.fill((255, 255, 255))
    cat.draw(screen)


    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()

    pygame.display.update()
    Clock.tick(40)
4