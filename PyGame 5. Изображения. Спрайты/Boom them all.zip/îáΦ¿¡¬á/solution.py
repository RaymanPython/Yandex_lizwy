import sys

import pygame
from pygame.locals import *
import random

width = 500
height = 500


class Bomb(pygame.sprite.Sprite):
    image = pygame.image.load("bomb.png")
    image_boom = pygame.image.load("boom.png")

    def __init__(self, group):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно !!!
        super().__init__(group)
        self.image = Bomb.image
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(width)
        self.rect.y = random.randrange(height)

    def update(self, *args):
        if args and args[0].type == pygame.MOUSEBUTTONDOWN and \
                self.rect.collidepoint(args[0].pos):
            self.image = self.image_boom


pygame.init()
screen = pygame.display.set_mode((width, height))
Clock = pygame.time.Clock()
all_sprites = pygame.sprite.Group()
for _ in range(20):
    all_sprites.add(Bomb(all_sprites))
running = True
while running:
    screen.fill((255, 255, 255))
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()

    all_sprites.draw(screen)
    all_sprites.update()
    pygame.display.update()
    Clock.tick(40)
